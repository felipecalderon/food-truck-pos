export const BACKEND_URL = process.env.BACKEND_URL || "http://localhost:3001";
