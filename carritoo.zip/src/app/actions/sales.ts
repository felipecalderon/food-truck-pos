'use server'

import type { CartItem } from "@/app/pos/types";
import fs from "node:fs/promises";
import path from "node:path";

// Helper para formatear la moneda
const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(amount);
}

export async function saveSale(
  cart: CartItem[], 
  total: number, 
  paymentMethod: string, 
  amountPaid: number, 
  change: number
): Promise<{ success: boolean; message: string }> {
  
  const saleTimestamp = new Date();
  const formattedDate = `${saleTimestamp.toLocaleDateString('es-CL')} ${saleTimestamp.toLocaleTimeString('es-CL')}`;

  // Formatear los items del carrito en una línea
  const itemsSummary = cart.map(item => `${item.nombre} (x${item.quantity})`).join(', ');

  // Línea a guardar en el log
  const saleRecord = `[${formattedDate}] Venta Total: ${formatCurrency(total)} | Método de Pago: ${paymentMethod} | Pagado: ${formatCurrency(amountPaid)} | Cambio: ${formatCurrency(change)} | Productos: ${itemsSummary}
`;

  try {
    const logFilePath = path.join(process.cwd(), 'sales.log');
    await fs.appendFile(logFilePath, saleRecord, 'utf-8');
    
    console.log(`Venta guardada exitosamente en ${logFilePath}`);
    return { success: true, message: 'Venta guardada con éxito.' };

  } catch (error) {
    console.error("Error al guardar la venta:", error);
    return { success: false, message: 'Error al guardar la venta.' };
  }
}
